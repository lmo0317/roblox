Egg Dash v0.3.0 - Reference layout rebuild (Godot 4.6.3)

Windows: unzip and run EggDash-Windows.exe. No engine installation needed.
Linux: chmod +x EggDash-Linux.x86_64; ./EggDash-Linux.x86_64

WASD Move | Space Jump | Shift Sprint | RMB Camera | Wheel Zoom
E Pick Up / Hatch / Upgrade | F11 Fullscreen | Esc Pause
Shop buys speed and base upgrades. Slow Mode toggles normal walking.
Progress saves automatically. Existing v0.1/v0.2 saves are retained.

1920x1080 reference UI; default 1280x720 resizable window.
192 x 320 world units, fenced pens, stud surfaces, five biome areas.
This is a reconstruction from gameplay screenshots, not an exact clone.
Map dimensions are estimates; assets and progression differ from Roblox.
Single-player; surrounding pets and pens are decoration.
Windows cross-built on Linux; Windows direct execution not verified.
Linux release passed gameplay/UI checks and actual rendering at 1280x720.

Source: https://github.com/lmo0317/roblox/tree/main/Godot
