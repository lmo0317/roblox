Egg Dash v0.2.0 - visual update (Godot 4.6.3)

Windows: unzip and run EggDash-Windows.exe. No Godot installation needed.
Linux: chmod +x EggDash-Linux.x86_64; ./EggDash-Linux.x86_64

WASD move, Space jump, Shift sprint, hold RMB to orbit.
E pick up eggs / hatch on blue HATCH pad / upgrade on marked pads.
Escape pauses the game. Progress saves automatically.

Includes the custom avatar, fox, pets, speckled eggs, woven nests,
base details, foliage, sky, lighting and HUD from gameplay-preview.png.
Single player. Windows cross-built on Linux, not run-tested on Windows.
Linux exported runtime gameplay checks and real rendering verified.

Source: https://github.com/lmo0317/roblox/tree/main/Godot
