Egg Dash v0.3.1 - Boundary walking fix

Windows: extract into a NEW folder and run EggDash-Windows.exe.
Linux: chmod +x EggDash-Linux.x86_64; ./EggDash-Linux.x86_64
No engine installation needed. Existing saves are retained.

Fixed: thin floor-overlay colliders blocked walking at Forest, other biome,
and pet-pen boundaries. Overlays now share the flat baseplate collider.
Verified 14 actual walking routes including solid fences and outer walls.
Linux release gameplay/UI and movement tests passed.
Windows cross-built on Linux; direct Windows execution not verified.

WASD Move | Space Jump | Shift Sprint | RMB Camera | Wheel Zoom
E Pick Up / Hatch / Upgrade | F11 Fullscreen | Esc Pause

Source: https://github.com/lmo0317/roblox
