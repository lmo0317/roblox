Egg Dash - Godot 4.6.3 prototype

WASD move, Space jump, Shift sprint, hold RMB to orbit camera.
E pick up eggs, hatch at blue HATCH pad, buy upgrades at marked pads.
Escape pauses the game.
Windows: run EggDash-Windows.exe.
Linux: chmod +x EggDash-Linux.x86_64; ./EggDash-Linux.x86_64

Single player. Windows binary cross-built on Linux; not run-tested on Windows.
Source: https://github.com/lmo0317/roblox
